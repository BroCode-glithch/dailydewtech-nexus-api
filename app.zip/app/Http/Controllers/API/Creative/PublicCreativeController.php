<?php

namespace App\Http\Controllers\API\Creative;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Chapter;
use App\Models\Story;
use App\Models\Tag;
use App\Support\CreativeRichText;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PublicCreativeController extends Controller
{
    public function stories(Request $request)
    {
        $query = Story::query()
            ->with(['author:id,name,username', 'coverImage:id,path,thumbnail_path,alt_text'])
            ->withCount(['likes', 'bookmarks', 'views'])
            ->published();

        if ($search = $request->input('search')) {
            $query->where(function ($builder) use ($search) {
                $builder->where('title', 'like', '%' . $search . '%')
                    ->orWhere('summary', 'like', '%' . $search . '%')
                    ->orWhere('description', 'like', '%' . $search . '%');
            });
        }

        if ($category = $request->input('category')) {
            $query->whereHas('categories', fn ($builder) => $builder->where('slug', $category));
        }

        if ($tag = $request->input('tag')) {
            $query->whereHas('tags', fn ($builder) => $builder->where('slug', $tag));
        }

        $sort = $request->input('sort', 'latest');
        if ($sort === 'trending') {
            $query->withCount(['views as recent_views_count' => function ($builder) {
                $builder->where('viewed_at', '>=', now()->subDays(7));
            }])->orderByDesc('recent_views_count');
        } else {
            $query->orderByDesc('published_at');
        }

        $stories = $query->paginate((int) $request->input('per_page', 12));

        return response()->json(['success' => true, 'data' => $stories]);
    }

    public function showStory(string $slug)
    {
        $story = Story::query()
            ->with([
                'author:id,name,username',
                'coverImage:id,path,thumbnail_path,alt_text',
                'categories:id,name,slug',
                'tags:id,name,slug',
                'chapters' => function ($builder) {
                    $builder->published()->orderBy('chapter_number');
                },
            ])
            ->withCount(['likes', 'bookmarks', 'views'])
            ->published()
            ->where('slug', $slug)
            ->firstOrFail();

        return response()->json(['success' => true, 'data' => $story]);
    }

    public function chapterReader(string $slug, int $chapterNumber)
    {
        $story = Story::query()->published()->where('slug', $slug)->firstOrFail();

        $chapter = Chapter::query()
            ->with(['featuredImage:id,path,thumbnail_path,alt_text'])
            ->published()
            ->where('story_id', $story->id)
            ->where('chapter_number', $chapterNumber)
            ->firstOrFail();

        $chapter->content_html = CreativeRichText::sanitize($chapter->content_html);

        $prev = Chapter::query()
            ->published()
            ->where('story_id', $story->id)
            ->where('chapter_number', '<', $chapter->chapter_number)
            ->orderByDesc('chapter_number')
            ->first(['id', 'chapter_number', 'title']);

        $next = Chapter::query()
            ->published()
            ->where('story_id', $story->id)
            ->where('chapter_number', '>', $chapter->chapter_number)
            ->orderBy('chapter_number')
            ->first(['id', 'chapter_number', 'title']);

        return response()->json([
            'success' => true,
            'data' => [
                'story' => [
                    'id' => $story->id,
                    'title' => $story->title,
                    'slug' => $story->slug,
                ],
                'chapter' => $chapter,
                'navigation' => [
                    'previous' => $prev,
                    'next' => $next,
                ],
            ],
        ]);
    }

    public function categories()
    {
        return response()->json([
            'success' => true,
            'data' => Category::query()->orderBy('name')->get(),
        ]);
    }

    public function tags()
    {
        return response()->json([
            'success' => true,
            'data' => Tag::query()->orderBy('name')->get(),
        ]);
    }

    public function trending(Request $request)
    {
        $days = max(1, min(30, (int) $request->input('days', 7)));
        $from = Carbon::now()->subDays($days);

        try {
            $stories = Story::query()
                ->published()
                ->with(['author:id,name,username', 'coverImage:id,path,thumbnail_path,alt_text'])
                ->withCount([
                    'views as views_window' => fn ($builder) => $builder->where('viewed_at', '>=', $from),
                    'likes as likes_window' => fn ($builder) => $builder->where('created_at', '>=', $from),
                ])
                ->get()
                ->map(function ($story) {
                    $story->trending_score = ((int) ($story->views_window ?? 0) * 1) + ((int) ($story->likes_window ?? 0) * 3);
                    return $story;
                })
                ->sortByDesc('trending_score')
                ->values()
                ->take(10);

            return response()->json(['success' => true, 'data' => $stories]);
        } catch (\Exception $e) {
            // Log the error internally but return safe response
            report($e);
            return response()->json([
                'success' => true,
                'data' => [],
                'message' => 'Trending data temporarily unavailable',
            ]);
        }
    }
}
