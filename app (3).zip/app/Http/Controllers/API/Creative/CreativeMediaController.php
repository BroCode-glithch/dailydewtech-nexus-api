<?php

namespace App\Http\Controllers\API\Creative;

use App\Http\Controllers\Controller;
use App\Models\Media;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class CreativeMediaController extends Controller
{
    public function upload(Request $request)
    {
        $payload = $request->validate([
            'file' => 'required|file|mimes:jpg,jpeg,png,webp|max:4096',
            'alt_text' => 'nullable|string|max:255',
        ]);

        $file = $payload['file'];
        $disk = 'public';
        $path = $file->store('creative/uploads', $disk);

        [$width, $height] = $this->imageSize($file->getRealPath());
        $thumbnailPath = $this->makeThumbnail($file->getRealPath(), $disk);

        $media = Media::create([
            'disk' => $disk,
            'path' => $path,
            'thumbnail_path' => $thumbnailPath,
            'mime_type' => $file->getMimeType() ?? 'application/octet-stream',
            'size_bytes' => $file->getSize() ?: 0,
            'width' => $width,
            'height' => $height,
            'alt_text' => $payload['alt_text'] ?? null,
            'uploaded_by' => optional($request->user())->id,
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'media_id' => $media->id,
                'url' => Storage::url($media->path),
                'thumbnail_url' => $media->thumbnail_path ? Storage::url($media->thumbnail_path) : null,
                'media' => $media,
            ],
        ], 201);
    }

    private function imageSize(string $path): array
    {
        $size = @getimagesize($path);
        if (!$size) {
            return [null, null];
        }

        return [(int) ($size[0] ?? 0), (int) ($size[1] ?? 0)];
    }

    private function makeThumbnail(string $sourcePath, string $disk): ?string
    {
        if (!function_exists('imagecreatetruecolor')) {
            return null;
        }

        $info = @getimagesize($sourcePath);
        if (!$info) {
            return null;
        }

        [$width, $height] = $info;
        if ($width < 2 || $height < 2) {
            return null;
        }

        $targetWidth = 360;
        $targetHeight = (int) round(($height / $width) * $targetWidth);

        $mime = $info['mime'] ?? '';
        $sourceImage = match ($mime) {
            'image/jpeg' => @imagecreatefromjpeg($sourcePath),
            'image/png' => @imagecreatefrompng($sourcePath),
            'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($sourcePath) : false,
            default => false,
        };

        if (!$sourceImage) {
            return null;
        }

        $thumb = imagecreatetruecolor($targetWidth, $targetHeight);
        imagecopyresampled($thumb, $sourceImage, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);

        $thumbRelativePath = 'creative/uploads/thumbs/' . Str::uuid() . '.jpg';
        $absolute = Storage::disk($disk)->path($thumbRelativePath);
        $dir = dirname($absolute);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        imagejpeg($thumb, $absolute, 85);
        imagedestroy($thumb);
        imagedestroy($sourceImage);

        return $thumbRelativePath;
    }
}
