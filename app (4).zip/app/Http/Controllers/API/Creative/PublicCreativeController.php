<?php

namespace App\Http\Controllers\API\Creative;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Chapter;
use App\Models\Story;
use App\Models\Tag;
use App\Models\User;
use App\Support\CreativeRichText;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PublicCreativeController extends Controller
{
    public function stories(Request $request)
    {
        $query = Story::query()
            ->with(['author:id,name,username', 'coverImage:id,path,thumbnail_path,alt_text'])
            ->withCount(['likes', 'bookmarks', 'views'])
            ->published();

        if ($search = $request->input('search')) {
            $query->where(function ($builder) use ($search) {
                $builder->where('title', 'like', '%' . $search . '%')
                    ->orWhere('summary', 'like', '%' . $search . '%')
                    ->orWhere('description', 'like', '%' . $search . '%');
            });
        }

        if ($category = $request->input('category')) {
            $query->whereHas('categories', fn($builder) => $builder->where('slug', $category));
        }

        if ($tag = $request->input('tag')) {
            $query->whereHas('tags', fn($builder) => $builder->where('slug', $tag));
        }

        $sort = $request->input('sort', 'latest');
        if ($sort === 'trending') {
            $query->withCount(['views as recent_views_count' => function ($builder) {
                $builder->where('viewed_at', '>=', now()->subDays(7));
            }])->orderByDesc('recent_views_count');
        } else {
            $query->orderByDesc('published_at');
        }

        $stories = $query->paginate((int) $request->input('per_page', 12));

        return response()->json(['success' => true, 'data' => $stories]);
    }

    public function showStory(Request $request, string $slug)
    {
        $story = $this->resolveReadableStory($request, $slug)
            ->with([
                'author:id,name,username',
                'coverImage:id,path,thumbnail_path,alt_text',
                'categories:id,name,slug',
                'tags:id,name,slug',
                'chapters' => function ($builder) {
                    $builder->orderBy('chapter_number');
                },
            ])
            ->withCount(['likes', 'bookmarks', 'views'])
            ->firstOrFail();

        if (!$this->canPreviewUnpublished($request, $story)) {
            $story->setRelation('chapters', $story->chapters->filter(function ($chapter) {
                return $chapter->status === 'published'
                    && !is_null($chapter->published_at)
                    && $chapter->published_at <= now();
            })->values());
        }

        return response()->json(['success' => true, 'data' => $story]);
    }

    public function chapterReader(Request $request, string $slug, int $chapterNumber)
    {
        $story = $this->resolveReadableStory($request, $slug)->firstOrFail();
        $canPreviewUnpublished = $this->canPreviewUnpublished($request, $story);

        $chapterQuery = Chapter::query()
            ->with(['featuredImage:id,path,thumbnail_path,alt_text'])
            ->where('story_id', $story->id)
            ->where('chapter_number', $chapterNumber);

        if (!$canPreviewUnpublished) {
            $chapterQuery->published();
        }

        $chapter = $chapterQuery->firstOrFail();

        $chapter->content_html = CreativeRichText::sanitize($chapter->content_html);

        $prevQuery = Chapter::query()
            ->where('story_id', $story->id)
            ->where('chapter_number', '<', $chapter->chapter_number)
            ->orderByDesc('chapter_number');

        $nextQuery = Chapter::query()
            ->where('story_id', $story->id)
            ->where('chapter_number', '>', $chapter->chapter_number)
            ->orderBy('chapter_number');

        if (!$canPreviewUnpublished) {
            $prevQuery->published();
            $nextQuery->published();
        }

        $prev = $prevQuery->first(['id', 'chapter_number', 'title']);

        $next = $nextQuery->first(['id', 'chapter_number', 'title']);

        return response()->json([
            'success' => true,
            'data' => [
                'story' => [
                    'id' => $story->id,
                    'title' => $story->title,
                    'slug' => $story->slug,
                ],
                'chapter' => $chapter,
                'navigation' => [
                    'previous' => $prev,
                    'next' => $next,
                ],
            ],
        ]);
    }

    private function resolveReadableStory(Request $request, string $slug)
    {
        $query = Story::query()->where('slug', $slug);

        $publishedStory = (clone $query)->published()->first();
        if ($publishedStory) {
            return Story::query()->where('id', $publishedStory->id);
        }

        $user = auth('sanctum')->user();
        if (!$user) {
            return Story::query()->where('id', 0);
        }

        if (in_array($user->role, ['admin', 'super_admin', 'editor'], true)) {
            return Story::query()->where('slug', $slug);
        }

        return Story::query()->where('slug', $slug)->where('author_id', $user->id);
    }

    private function canPreviewUnpublished(Request $request, Story $story): bool
    {
        if ($story->status === 'published') {
            return true;
        }

        /** @var User|null $user */
        $user = auth('sanctum')->user();
        if (!$user) {
            return false;
        }

        if ((int) $story->author_id === (int) $user->id) {
            return true;
        }

        return in_array($user->role, ['admin', 'super_admin', 'editor'], true);
    }

    public function categories()
    {
        return response()->json([
            'success' => true,
            'data' => Category::query()->orderBy('name')->get(),
        ]);
    }

    public function tags()
    {
        return response()->json([
            'success' => true,
            'data' => Tag::query()->orderBy('name')->get(),
        ]);
    }

    public function trending(Request $request)
    {
        $days = max(1, min(30, (int) $request->input('days', 7)));
        $from = Carbon::now()->subDays($days);

        try {
            $stories = Story::query()
                ->published()
                ->with(['author:id,name,username', 'coverImage:id,path,thumbnail_path,alt_text'])
                ->withCount([
                    'views as views_window' => fn($builder) => $builder->where('viewed_at', '>=', $from),
                    'likes as likes_window' => fn($builder) => $builder->where('created_at', '>=', $from),
                ])
                ->get()
                ->map(function ($story) {
                    $story->trending_score = ((int) ($story->views_window ?? 0) * 1) + ((int) ($story->likes_window ?? 0) * 3);
                    return $story;
                })
                ->sortByDesc('trending_score')
                ->values()
                ->take(10);

            return response()->json(['success' => true, 'data' => $stories]);
        } catch (\Exception $e) {
            // Log the error internally but return safe response
            report($e);
            return response()->json([
                'success' => true,
                'data' => [],
                'message' => 'Trending data temporarily unavailable',
            ]);
        }
    }
}
