<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Posts;
use App\Models\Projects;
use Illuminate\Support\Str;

class ShareMetaController extends Controller
{
    public function project(string $identifier)
    {
        $project = Projects::query()
            ->where('status', 'published')
            ->where(function ($query) use ($identifier) {
                $query->where('slug', $identifier);

                if (ctype_digit($identifier)) {
                    $query->orWhere('id', (int) $identifier);
                }
            })
            ->firstOrFail();

        $title = $project->title;
        $description = Str::limit(strip_tags((string) $project->description), 200);
        $slug = (string) ($project->slug ?: $project->id);

        return response()->view('share.meta', [
            'title' => $title,
            'description' => $description,
            'image' => $this->resolveImageUrl($project->thumbnail),
            'url' => url('/share/projects/' . $slug),
            'frontendUrl' => rtrim((string) config('app.frontend_url'), '/') . '/projects/' . $slug,
            'siteName' => (string) config('app.name', 'Daily Dew Tech'),
            'type' => 'article',
        ]);
    }

    public function blog(string $identifier)
    {
        $post = Posts::query()
            ->where('status', 'published')
            ->where(function ($query) use ($identifier) {
                $query->where('slug', $identifier);

                if (ctype_digit($identifier)) {
                    $query->orWhere('id', (int) $identifier);
                }
            })
            ->firstOrFail();

        $title = $post->title;
        $description = Str::limit(strip_tags((string) ($post->excerpt ?: $post->content)), 200);
        $slug = (string) ($post->slug ?: $post->id);

        return response()->view('share.meta', [
            'title' => $title,
            'description' => $description,
            'image' => $this->resolveImageUrl($post->cover_image),
            'url' => url('/share/blog/' . $slug),
            'frontendUrl' => rtrim((string) config('app.frontend_url'), '/') . '/blog/' . $slug,
            'siteName' => (string) config('app.name', 'Daily Dew Tech'),
            'type' => 'article',
        ]);
    }

    private function resolveImageUrl(?string $image): ?string
    {
        if (!$image) {
            return null;
        }

        if (Str::startsWith($image, ['http://', 'https://'])) {
            return $image;
        }

        if (Str::startsWith($image, ['/storage/', '/'])) {
            return url($image);
        }

        if (Str::startsWith($image, 'storage/')) {
            return url('/' . $image);
        }

        return asset('storage/' . ltrim($image, '/'));
    }
}
