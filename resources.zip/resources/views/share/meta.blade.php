<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title }}</title>
    <meta name="description" content="{{ $description }}">

    <meta property="og:site_name" content="{{ $siteName }}">
    <meta property="og:type" content="{{ $type }}">
    <meta property="og:title" content="{{ $title }}">
    <meta property="og:description" content="{{ $description }}">
    <meta property="og:url" content="{{ $url }}">
    @if (!empty($image))
        <meta property="og:image" content="{{ $image }}">
    @endif

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{{ $title }}">
    <meta name="twitter:description" content="{{ $description }}">
    @if (!empty($image))
        <meta name="twitter:image" content="{{ $image }}">
    @endif

    <meta http-equiv="refresh" content="0;url={{ $frontendUrl }}">
    <link rel="canonical" href="{{ $frontendUrl }}">
    <script>
        window.location.replace(@json($frontendUrl));
    </script>
</head>

<body>
    <p>Redirecting to <a href="{{ $frontendUrl }}">{{ $frontendUrl }}</a></p>
</body>

</html>
